package student.newinti.androidapp;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;

public class function_viewdata extends AppCompatActivity {

    DatabaseHelper myDB;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewdata);

        ListView listView = findViewById(R.id.listView);
        myDB = new DatabaseHelper(this);

        ArrayList<String> listItem = new ArrayList<>();
        Cursor data = myDB.viewRentedData();

        if (data.getCount() == 0 ) {
            Toast.makeText(function_viewdata.this, "Don't Have Any Data", Toast.LENGTH_LONG).show();
        } else {
            while(data.moveToNext()) {
                listItem.add(data.getString(1));
                ListAdapter listAdapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,listItem);
                listView.setAdapter(listAdapter);
            }
        }
    }
}
